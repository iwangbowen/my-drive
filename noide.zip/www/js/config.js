var config = {
	fundodooApiDomainUrl : 'http://localhost:8080/api/',
	fundodooWebDomainUrl : 'http://127.0.0.1:7080/web/',
	login : 'http://127.0.0.1:7080/api/UserLogin',
	whiteList : {
		login : 'http://127.0.0.1:7080/api/UserLogin',
		allOwnerList : 'http://127.0.0.1:7080/api/LoginOwnersQuery'
	}
};